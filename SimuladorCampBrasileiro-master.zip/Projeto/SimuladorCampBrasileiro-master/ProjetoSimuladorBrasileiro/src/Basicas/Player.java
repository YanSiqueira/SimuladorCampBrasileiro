package Basicas;

public class Player extends Perfil {
	//atributos
	Clube clube;
	Campeonato campeonato;
	String titulos;
	
	//construtor
	public Player(String nome, int id,String loging, String senha,Clube clube,Campeonato campeonato,String titulos) {
		super(nome,id,loging,senha);
		
	}
	
	//metodos est�o na classe ControlePlayer
	
	
 }