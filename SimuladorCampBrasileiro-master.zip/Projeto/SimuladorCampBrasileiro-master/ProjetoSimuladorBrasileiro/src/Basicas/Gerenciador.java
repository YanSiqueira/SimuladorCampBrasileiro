package Basicas;

public class Gerenciador extends Perfil{
	 //construdor
		public Gerenciador(String nome, int id, String loging, String senha) {
			super(nome, id, loging, senha);
			// TODO Auto-generated constructor stub
		}
	//os metodos foram para a classe ControleGerenciador
	}
