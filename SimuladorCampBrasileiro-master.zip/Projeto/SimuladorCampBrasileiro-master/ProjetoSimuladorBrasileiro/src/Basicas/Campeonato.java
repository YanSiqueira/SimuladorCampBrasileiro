package Basicas;

public class Campeonato {

}
