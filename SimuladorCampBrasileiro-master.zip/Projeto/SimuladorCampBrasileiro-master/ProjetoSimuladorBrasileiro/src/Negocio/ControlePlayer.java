package Negocio;

public class ControlePlayer {
	
	
	
	private RepositorioPerfis perfis = new RepositorioPerfisArray();
	
	
	
	public void inserir(Perfil perfil) {
		perfis.inserir(perfil);
	}
	public void atualizar(Perfil perfil) {
		perfis.atualizar(perfil);
	}
	public void buscar(int id) {
		// esse metodo pode ser executado  so antes do campeonato come�ar
		perfis.buscar(id);
	}
	public void remover(int id) {
		perfis.remover(id);
	}
	
	

	public void escalacaoTime(int idClube, int idJogador) {
		 	
		
		
		 		
		 	
		
	}
	
	public void iniciarPartida() {
		
		
	}
	
	public void historicoPartida() {
		
		
		
	}
	
	
	public void salvarPartida() {
		
		
	}
	
	public void esquemaTatico() {
		
		
	}
	
	
	public void exibeCalendario() {
		
		
	}
	
	
	public void exibirHistoricoPartidas() {
		
		
	}
	

}
